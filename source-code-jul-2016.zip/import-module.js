console.log('Code A')
module.exports = function(options){
  console.log('Code B')
}