// main.js
var m = require('./module')
console.log(m.b) // 3
