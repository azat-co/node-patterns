var f = require('./import-module.js')

require('./import-module.js')