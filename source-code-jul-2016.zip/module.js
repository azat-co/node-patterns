// module.js
var a = 1 // Private
module.exports = {
  b: 2 // Public
}
