require('./redlog')
console.log('I am red!')